def joke():
    ''' python-packaging '''
    return (u'Wenn ist das Nunst\u00fcck git und Slotermeyer? Ja! ... '
            u'Beiherhund das Oder die Flipperwaldt gersput.')
# setup  => pip install .
# usage  => nnPackage.joke()
# Vact84dgTwfHg2R
# distibution => python setup.py sdist
