from setuptools import setup

setup(name='nnPackage',
      version='0.1',
      description='Nabeel Najjar Package 1',
      url='http://github.com/storborg/funniest',
      author='Nabeel Najjar',
      author_email='N.Najjar@gmail.com',
      license='MIT',
      packages=['nnPackage'],
      zip_safe=False)