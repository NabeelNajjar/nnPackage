from setuptools import setup

setup(name='nnpackage',
      version='0.1',
      description='Nabeel Najjar Package 1',
      url='https://github.com/NabeelNajjar/nnPackage',
      author='Nabeel Najjar',
      author_email='N.Najjar@gmail.com',
      license='MIT',
      packages=['nnpackage'],
      zip_safe=False)