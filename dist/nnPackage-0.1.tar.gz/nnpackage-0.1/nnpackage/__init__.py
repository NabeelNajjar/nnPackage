from .text import joke2

