def joke2():
    ''' python-packaging '''
    return (u'Wenn ist das Nunst\u00fcck git und Slotermeyer? Ja! ... '
            u'Beiherhund das Oder die Flipperwaldt gersput.')
# setup  => pip install -U .
# usage  => nnPackage.joke()
# Vact84dgTwfHg2R
# distibution => python setup.py sdist
#                python setup.py register sdist upload

'''
git init .
git add .
git commit -m "1st package"
    create one on github  , add collaborator
git remote add origin https://github.com/NabeelNajjar/nnPackage
git push --set-upstream origin master

[pypi]
  username = nabnaj
  password = pypi-AgEIcHlwaS5vcmcCJDIxZGQ3YmRmLTFhMGItNGRjMy05YzFlLTE1ZDlhYzI4Y2Y0MgACJXsicGVybWlzc2lvbnMiOiAidXNlciIsICJ2ZXJzaW9uIjogMX0AAAYgEIj2_C1YIXb3hjfrvt0VkvvaF7ynMyKtvggf-Q4c67g

'''

